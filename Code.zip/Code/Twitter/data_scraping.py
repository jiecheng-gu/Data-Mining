#!/usr/bin/python
#!/usr/bin/env python
import requests
import os
import json
import pandas as pd
from pandas import json_normalize
import csv
# For parsing the dates received from twitter in readable formats
import datetime
import dateutil.parser
import unicodedata
#To add wait time between requests
import time

os.environ['BEARER_TOKEN'] = '' #

def auth():
    '''retrieve the token from the environment'''
    return os.getenv('BEARER_TOKEN')

def create_headers(bearer_token):
    '''Create Headers'''
    headers = {"Authorization": "Bearer {}".format(bearer_token)}
    return headers

def create_url(keyword, start_date, end_date, max_results=10):
    '''create URL'''
    search_url = "https://api.twitter.com/2/tweets/search/all"

    #change params based on the endpoint you are using
    query_params = {'query': keyword,
                    'start_time': start_date,
                    'end_time': end_date,
                    'max_results': max_results,
                    'expansions': 'author_id,referenced_tweets.id',
                    'user.fields': 'id,name,username,description,location,verified,profile_image_url',
                    'tweet.fields':'text,created_at',
                    'next_token': {}
                    }
    return (search_url, query_params)

def connect_to_endpoint(url, headers, params, next_token = None):
    '''Connect to Endpoint'''
    params['next_token'] = next_token   # params object received from create_url function
    response = requests.request("GET", url, headers = headers, params = params)
    print("Endpoint Response Code: " + str(response.status_code))
    if response.status_code != 200:
        raise Exception(response.status_code, response.text)
    return response.json()

def write_to_csv(response, filename):
    '''load data onto a csv file'''    
    data = json_normalize(response["data"])   
    users = json_normalize(response["includes"]["users"])    
    # print(users.columns)
    tweets = json_normalize(response["includes"]["tweets"])
    # print(tweets.columns)
    data_new = data[['author_id', 'id', 'referenced_tweets', 'text', 'created_at']]
    data_new.to_csv("./"+filename[0], index=False, header=False, mode='a')
    users_new = users[['verified', 'name', 'username', 'profile_image_url', 'id', 'description', 'location']]
    users_new.to_csv("./"+filename[1], index=False, header=False, mode='a')
    tweets_new = tweets[['id', 'created_at', 'text', 'author_id', 'referenced_tweets']]
    tweets_new.to_csv("./"+filename[2], index=False, header=False, mode='a')

def main():
    #Inputs for the request
    bearer_token = auth()
    headers = create_headers(bearer_token)
    keyword = "\"online learning\" OR \"remote learning\" OR \"distance learning\" OR #onlinelearning OR #remotelearning OR #distancelearning"
    start_time = "2021-03-01T00:00:00.00Z"
    end_time = "2021-05-01T00:00:00.00Z"
    max_results = 500

    next_token = {}
    total_tweets = 0
    max_tweets = 1000000
    flag = True
    while flag:
        if(total_tweets >= max_tweets):
            if 'next_token' in json_response['meta']:
                print("Reach max_tweets, next Token: ", next_token)
                break
        print("-------------------")
        print("Token: ", next_token)
        url = create_url(keyword, start_time, end_time, max_results)
        json_response = connect_to_endpoint(url[0], headers, url[1], next_token)
        # print(json.dumps(json_response, indent=4, sort_keys=True)) # print the response in a readable format
        result_count = json_response['meta']['result_count']

        if 'next_token' in json_response['meta']:
             # Save the token to use for next call
            next_token = json_response['meta']['next_token']
            print("Next Token: ", next_token)
            if result_count is not None and result_count > 0 and next_token is not None:
                print("Start Date: ", json_normalize(json_response["data"])["created_at"][0])
                write_to_csv(json_response, ["data.csv", "users.csv", "tweets.csv"])
                total_tweets += result_count
                print("Total # of Tweets added: ", total_tweets)
                print("-------------------")
                time.sleep(5) 
        else: # If no next token exists
            if result_count is not None and result_count > 0:
                print("-------------------")
                print("Start Date: ", json_normalize(json_response["data"])["created_at"][0])
                write_to_csv(json_response, ["data.csv", "users.csv", "tweets.csv"])
                total_tweets += result_count
                print("Total # of Tweets added: ", total_tweets)
                print("-------------------")
                time.sleep(5)            
            # The final request, turn flag to false to move to the next time period.            
            flag = False
            next_token = {}
        time.sleep(5)
    print("Finished data collection")

if __name__ == "__main__":
    main()



    
