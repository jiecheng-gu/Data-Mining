import codecs
import json
import pandas as pd
import jieba
import pickle
import re
from langconv import *

def Traditional2Simplified(sentence):
  
    sentence = Converter('zh-hans').convert(sentence)
    return sentence

def Sent2Word(sentence):

    global stop_words

    words = jieba.cut(sentence)
    words = [w for w in words if w not in stop_words]
    return words


def Match(content):

    sentence_word = []
    advertisement = ["券后", "售价", '¥', "abcmouse", '开心鼠',"粉丝","tfboys"]

    for k in range(0, len(content)):
        judge = []
        content[k]['content'] = Traditional2Simplified(content[k]['content'])
        for adv in advertisement:
            if adv in content[k]['content']:
                judge.append("True")
                break
        if re.search(r"买.*赠.*", content[k]['content']):
            judge.append("True")
            continue
        # Advertisement
        if "True" not in judge:
            sentence_word.append(content[k]['content'])
            # Denoise
            a2 = re.compile(r'#.*?#')
            content[k]['content'] = a2.sub('', content[k]['content'])
            a3 = re.compile(r'\[组图共.*张\]')
            content[k]['content'] = a3.sub('', content[k]['content'])
            a4 = re.compile(r'http:.*')
            content[k]['content'] = a4.sub('', content[k]['content'])
            a5 = re.compile(r'@.*? ')
            content[k]['content'] = a5.sub('', content[k]['content'])
            a6 = re.compile(r'\[.*?\]')
            content[k]['content'] = a6.sub('', content[k]['content'])
            sentence_word.append(Sent2Word(content[k]['content']))
    #print(sentence_word)
    pickle.dump(sentence_word, open('./my_agu.pkl', 'wb'))


if __name__ == '__main__':

    print("Reading stop words...")
    stop_words = [w.strip() for w in open('./dict/哈工大停用词表.txt', 'r', encoding='UTF-8').readlines()]
    stop_words.extend(['\n', '\t', ' ', '回复', '转发微博', '转发', '微博', '秒拍', '秒拍视频', '视频', "网页", "链接"])
    for i in range(128000, 128722 + 1):
        stop_words.extend(chr(i))
    stop_words.extend(['网课',"上网课","王源","tfboys","都","课","网","还"])

    # pandas csv文档读法
    df_weibo = pd.read_csv('../content.csv')
   
    print("Reading Contents...")

    content = []
    for i in range(0,df_weibo.shape[0]):
         content.append({'content': df_weibo.loc[i,'微博正文']})
    
    Match(content)