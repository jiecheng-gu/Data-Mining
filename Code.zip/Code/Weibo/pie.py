import pandas as pd
from collections import Counter
from numpy import max, min, mean,quantile, median

from example.commons import Collector, Faker
from pyecharts import options as opts
from pyecharts.charts import Page, Pie

'''
snow_score = pd.read_csv('../score.csv')
#print(snow_score)
senti_dict = {}
print("Sentiment Score From Snow NLP")
q5 = snow_score.quantile(0.05)['Score']
q95 = snow_score.quantile(0.95)['Score']

senti_list = []
for i in snow_score['Score']:
    if (i <= q95) and (i >= q5):
        senti_list.append(i)

for i in senti_list:
    if 0 <= i < 0.2:
        senti_dict['Extreme Negative'] = senti_dict.get("Extreme Negative", 0) + 1
    elif 0.2 <= i < 0.4:
        senti_dict['Negative'] = senti_dict.get("Negative", 0) + 1
    elif 0.4 <= i < 0.6:
        senti_dict['Neutral'] = senti_dict.get("Neutral", 0) + 1
    elif 0.6 <= i < 0.8:
        senti_dict['Positive'] = senti_dict.get("Positive", 0) + 1
    elif 0.8 <= i:
        senti_dict['Extreme Positive'] = senti_dict.get("Extreme Positive", 0) + 1

data = []
for k, v in senti_dict.items():
    data1 = []
    data1.append(k)
    data1.append(v)
    data.append(data1)
    
'''
df_weibo = pd.read_csv('my_Senti_Keyword_total.csv', sep=',', encoding='gb18030')
df_weibo = df_weibo.drop(['微博内容','TextRank关键词'], axis=1)
#  winsorize 去除极端值
q5 = df_weibo.quantile(0.05)['情感得分']
q95 = df_weibo.quantile(0.95)['情感得分']

senti_list = []
for i in df_weibo['情感得分']:
    if (i <= q95) and (i >= q5):
        senti_list.append(i)
senti_dict = {}

senti_max = max(senti_list)
senti_min = min(senti_list)
senti_mean = mean(senti_list)
senti_25 = (senti_mean - senti_min) / 2
senti_75 = (senti_max - senti_mean) / 2
print("Sentiment Score From dict")

t = (senti_max - senti_min)/5
print(senti_min+t, senti_min+2*t, senti_min+3*t, senti_min+4*t)
for i in senti_list:
    if i < senti_min+t:
        senti_dict['Extreme Negative'] = senti_dict.get("Extreme Negative", 0) + 1
    elif senti_min+t <= i < senti_min+2*t:
        senti_dict['Negative'] = senti_dict.get("Negative", 0) + 1
    elif senti_min+2*t <= i < senti_min+3*t:
        senti_dict['Neutral'] = senti_dict.get("Neutral", 0) + 1
    elif senti_min+3*t <= i < senti_min+4*t:
        senti_dict['Positive'] = senti_dict.get("Positive", 0) + 1
    elif senti_min+4*t <= i:
        senti_dict['Extreme Positive'] = senti_dict.get("Extreme Positive", 0) + 1
        
data = []

for k, v in senti_dict.items():
    data1 = []
    data1.append(k)
    data1.append(v)
    data.append(data1)

C = Collector()


@C.funcs
def pie_base() -> Pie:
    c = (
        Pie()
        .add("", data)
        .set_global_opts(title_opts=opts.TitleOpts(title="PieChart"))
        .set_series_opts(label_opts=opts.LabelOpts(formatter="{b}:{d}%"))
    )
    return c

Page().add(*[fn() for fn, _ in C.charts]).render(u'./pie.html')
