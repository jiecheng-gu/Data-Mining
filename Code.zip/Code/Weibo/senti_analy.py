import sys
import numpy as np
from collections import defaultdict
import pickle
import heapq
from jieba import analyse
import csv

def LoadDict():
    
    # Sentiment word
    senti_file = open('./dict/BosonNLP_sentiment_score.txt', 'r+', encoding='utf-8')

    senti_list = senti_file.read().splitlines()
    senti_dict = defaultdict()
    
    for s in senti_list:
        
        if len(s.split(' ')) == 2:
            senti_dict[s.split(' ')[0]] = s.split(' ')[1]

    not_words = open('./dict/否定词.txt', encoding='UTF-8').readlines()
    not_dict = {}
    for w in not_words:
        word = w.strip()
        not_dict[word] = float(-1)

    degree_words = open('./dict/degreeDict.txt', 'r+', encoding='utf-8').readlines()
    degree_dict = {}
    for w in degree_words:
        word, score = w.strip().split(',')
        degree_dict[word] = float(score)

    return senti_dict, not_dict, degree_dict


senti_dict, not_dict, degree_dict = LoadDict()


def LocateSpecialWord(senti_dict, not_dict, degree_dict, sent):

    senti_word = {}
    not_word = {}
    degree_word = {}

    for index, word in enumerate(sent):
        if word in senti_dict:
            senti_word[index] = senti_dict[word]
        elif word in not_dict:
            not_word[index] = -1.0
        elif word in degree_dict:
            degree_word[index] = degree_dict[word]

    return senti_word, not_word, degree_word


def ScoreSent(senti_word, not_word, degree_word, words):
    
    W = 1
    score = 0

    # The location of sentiment words
    senti_locs = list(senti_word.keys())
    not_locs = list(not_word.keys())
    degree_locs = list(degree_word.keys())

    sentiloc = -1

    # iterate every word, i is the word index ("location")
    for i in range(0, len(words)):
        # if the word is positive
        if i in senti_locs:
            sentiloc += 1
            # update sentiment score
            score += W * float(senti_word[i])

            if sentiloc < len(senti_locs) - 1:
                # if there exists Not words or Degree words between
                # this sentiment word and next sentiment word
                # j is the word index ("location")
                for j in range(senti_locs[sentiloc], senti_locs[sentiloc + 1]):
                    # if there exists Not words
                    if j in not_locs:
                        W *= -1
                    # if there exists degree words
                    elif j in degree_locs:
                        W *= degree_word[j]

    return score

if __name__ == '__main__':
    content_comment = pickle.load(open('./my_agu.pkl', 'rb'))
    print('-'*40)
    print('Sentiment Analysis')
    print('-'*40)
    out = open('my_Senti_Keyword_total.csv', 'a', newline='', encoding='gb18030')
    csv_write = csv.writer(out, dialect='excel')

    stu1 = ['微博内容', 'words','情感得分','TF-IDF关键词', 'TextRank关键词']
    csv_write.writerow(stu1)
    senti_dict, not_dict, degree_dict = LoadDict()
    count = 1
    for i in range(0,len(content_comment)):
        senti = []
        if i % 2 ==0:
            #print("处理到：", content_comment[i])
            senti.append(content_comment[i])
            senti.append(content_comment[i+1])
            if len(content_comment[i+1]) > 4:
                senti_word, not_word, degree_word = LocateSpecialWord(senti_dict, not_dict, degree_dict, content_comment[i+1])
                score = ScoreSent(senti_word, not_word, degree_word, content_comment[i+1])
            else:
                score = 0
            senti.append(score)
        
            # TF-idf
            word_tf_idf = ''
            for x, w in analyse.extract_tags(str(content_comment[i]), topK=10, withWeight=True):
                word_tf_idf += x
                word_tf_idf += ' '
            senti.append(word_tf_idf)
    
            # TextRank
            word_textrank = ''
            for x, w in analyse.textrank(str(content_comment[i]), topK=10, withWeight=True):
                word_textrank += x
                word_textrank += ' '
            senti.append(word_textrank)
        
            csv_write.writerow(senti)
        count += 1
        
