import sys
from jieba import analyse
import pandas as pd
import gensim 
import pickle
import csv

df_weibo = pd.read_csv('my_Senti_Keyword_total.csv', sep=',', encoding='gb18030')
df_weibo = df_weibo.drop(['微博内容','情感得分','words'], axis=1)
words =df_weibo['TextRank关键词'].dropna().tolist()
#print(words)
texts =[]
for w in words:
    temp = w.split(' ')
    texts.append(temp[0:4])
# Dictionary
dictionary = gensim.corpora.Dictionary(texts)
corpus = [dictionary.doc2bow(text) for text in texts]

out = open('t.csv', 'a', newline='', encoding='gb18030')
csv_write = csv.writer(out, dialect='excel')
stu1 = ['主题数标号', '主题']
csv_write.writerow(stu1)

lda = gensim.models.ldamodel.LdaModel(corpus=corpus, id2word=dictionary, num_topics=12)
#print(lda.print_topics(num_topics=2,num_words =5))

for topic in lda.print_topics(num_topics=12, num_words=5):
    lda_1 = []
    lda_1.append(topic[0])
    lda_1.append(topic[1])
    csv_write.writerow(lda_1)
